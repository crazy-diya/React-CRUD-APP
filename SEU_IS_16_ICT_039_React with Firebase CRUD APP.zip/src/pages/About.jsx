import React from 'react'

const About = () => {
  return (
    <div>
      <h2>About Page</h2>
      <p>Im Dimuthu Lakshan. I created this for the Acedamic purpose only.</p>
    </div>
  )
}

export default About